# -*- coding: utf-8 -*-
"""
Created on Fri Aug  9 10:38:07 2019

@author: zhang
"""

import glob
from cfDNApipe import *

# set global configure
pipeConfigure(
    threads=60,
    genome="hg19",
    refdir="/home/zhangwei/Genome/hg19_bowtie2",
    outdir="/home/zhangwei/pipeline-WGS-comp",
    data="WGS",
    type="paired",
    case="normal",
    ctrl="cancer",
    build=True,
)

print("start analysing...")


# case
res6 = bamsort(bamInput = glob.glob("/home/zhangwei/pipeline-WGS-comp/case_raw/*.bam"))
res7 = qualimap(upstream=res6)
res7 = rmduplicate(upstream=res6, stepNum=8)
res8 = addRG(upstream=res7, picardJar="/opt/tsinghua/cfDNApipeTest/software/picard.jar")

# WGS-SNV pipeline
res9 = BaseRecalibrator(
    upstream=res8, knownSitesDir=r"/opt/tsinghua/cfDNApipeTest/file/vcf"
)
res10 = BQSR(upstream=res9)

res11 = getPileup(
    upstream=res10,
    biallelicvcfInput="/opt/tsinghua/cfDNApipeTest/file/small_exac_common_3_hg19.SNP_biallelic.vcf",
)
res12 = contamination(upstream=res11)

res13 = mutect2t(
    caseupstream=res12,
    vcfInput="/opt/tsinghua/cfDNApipeTest/file/af-only-gnomad.raw.sites.hg19.vcf.gz",
    ponbedInput="/opt/tsinghua/cfDNApipeTest/file/vcf/pon/somatic-hg19_Mutect2-WGS-panel.vcf.gz",
)
res14 = filterMutectCalls(upstream=res13)
res15 = gatherVCF(upstream=res14)

res16 = annovar(
    upstream=res15,
    plInput="/opt/tsinghua/cfDNApipeTest/software/annovar/annovar/table_annovar.pl",
    dbdir="/opt/tsinghua/cfDNApipeTest/software/annovar/annovar/humandb/",
)
res17 = annovarStat(upstream=res16,)


# virus detect
res18 = unmapfasta(
    upstream=res5,
    stepNum=18,
    plInput="/opt/tsinghua/cfDNApipeTest/software/VirusFinder2.0Plus/preprocessPlus_V2.pl",
)
res19 = virusdetect(
    upstream=res18,
    plInput="/opt/tsinghua/cfDNApipeTest/software/VirusFinder2.0Plus/detect_virusPlus.pl",
    virusDB="/opt/tsinghua/cfDNApipeTest/file/virus_genome/viral_REFSEQ.fa",
    blastnIdxH="/opt/tsinghua/cfDNApipeTest/file/hg19/bowtie2/hg19",
    blastnIdxV="/opt/tsinghua/cfDNApipeTest/file/virus_genome/viral_REFSEQ",
    pyscript="/opt/tsinghua/cfDNApipeTest/file/virus_genome/virusID2name.py",
    virusIDfile="/opt/tsinghua/cfDNApipeTest/file/virus_genome/virus_name_list.txt",
)
res20 = seqtk(upstream=res19)
res21 = BSVF(
    upstream1=res4,
    upstream2=res20,
    plInput="/opt/tsinghua/cfDNApipeTest/software/BSVF/BSVF_prepare_configFile.pl",
    bsuit="/opt/tsinghua/cfDNApipeTest/software/BSVF/bsuit",
    hostRef="/opt/tsinghua/cfDNApipeTest/file/hg19/hg19_EBV.fa",
)

# cnv
res22 = cnvbatch(
    caseupstream=res7,
    access="/opt/tsinghua/cfDNApipeTest/file/CNVkit/access-5kb-mappable.hg19.bed",
    annotate="/opt/tsinghua/cfDNApipeTest/file/CNVkit/refFlat_hg19.txt",
    stepNum=22,
)
res23 = cnvPlot(upstream=res22)
res24 = cnvTable(upstream=res22)
res25 = cnvHeatmap(upstream=res22)


print("analysis end...")
