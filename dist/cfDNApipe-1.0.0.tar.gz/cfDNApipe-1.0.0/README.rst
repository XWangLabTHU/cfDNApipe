# cfDNA-Pipeline
Cell Free DNA Sequencing Analysis Pipeline


# News
version 0.0.1, 2019.06.01
The first test version.

version 0.0.4, 2019.11.24
Add functions to check the reference folder when setting configure.

version 0.0.8, 2020.06.12
Add pipeline analysis function. Include WGS/WGBS paired/single data pipeline 
and case control comparison analysis pipeline.

version 0.0.9, 2020.06.17
Delete useless folders, remove stepBase2.

version 0.1.0, 2020.06.22
Add pipeline for basic WGS/WGBS and case/control analysis.

version 0.1.1, 2020.06.22
Add qualimap function.

version 0.1.3, 2020.12.01
Archive some functions.

version 0.1.5, 2021.01.05
Pre release.

version 0.1.6, 2021.01.05
Pre release again.

version 0.1.7, 2021.01.11
update report 

version 0.1.8, 2021.01.11
fix virus genome error

version 0.1.9, 2021.01.15
test data check

version 1.0.0, 2021.01.16
release