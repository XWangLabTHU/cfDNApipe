# -*- coding: utf-8 -*-
"""
Created on Fri Dec 13 19:32:30 2019

@author: Wei Zhang

E-mail: w-zhang16@mails.tsinghua.edu.cn
"""
class compConfigure:
    __config = {
    'threads': (cpu_count() / 2),
    'genome': None,
    'refdir': None,
    'outdir': None,
    'data': None,
    'type': 'paired',
    'case': 'case',
    'ctrl': 'ctrl'
    }

    def __init__(self,):
        '''
        threads: int, how many thread to use, default: (cpu_count() / 2)
        genome: str, which genome you want to use, 'hg19' or 'hg38'
        refdir: reference folder for aligner (bowtie2 or bismark)
        outdir: overall result folder
        tmpdir: intermediate result folder
        finaldir: most commonly used result folder
        repdir: report result folder
        data: data type, 'WGBS' or 'WGS'
        type: data type, 'paired' or 'single'
        '''
        raise commonError('Configure can not be initialized')


    # get configure through name
    @classmethod
    def getConfig(cls, key):
        return cls.__config[key]

    # set configure through name
    @classmethod
    def setConfig(cls, key, val):
        if key == 'threads':
            compConfigure.setThreads(val)
        elif key == 'genome':
            compConfigure.setGenome(val)
        elif key == 'outdir':
            compConfigure.setOutDir(val)
        elif key == 'refdir':
            compConfigure.setRefDir(val)
        elif key == 'data':
            compConfigure.setData(val)
        elif key == 'type':
            compConfigure.setType(val)
        elif key == 'case':
            compConfigure.setCase(val)
        elif key == 'ctrl':
            compConfigure.setCtrl(val)
        else:
            cls.__config[key] = val

    # set thread
    @classmethod
    def setData(cls, val):
        cls.__config['data'] = val

    # get thread
    @classmethod
    def getData(cls):
        return cls.__config['data']
    
    # set thread
    @classmethod
    def setType(cls, val):
        cls.__config['type'] = val

    # get thread
    @classmethod
    def getType(cls):
        return cls.__config['type']

    # set thread
    @classmethod
    def setThreads(cls, val):
        if compConfigure.getData() is None:
            raise commonError("Please set data type before using setThreads.")
            
        cls.__config['threads'] = val

    # get thread
    @classmethod
    def getThreads(cls):
        return cls.__config['threads']

    # set reference path
    @classmethod
    def setRefDir(cls, folderPath):
        if compConfigure.getGenome() is None:
            raise commonError("Please set genome before using setRefDir.")
            
        compConfigure.checkFolderPath(folderPath)
        cls.__config['refdir'] = folderPath


    # get reference path
    @classmethod
    def getRefDir(cls,):
        return cls.__config['refdir']

    @classmethod
    def setOutDir(cls, folderPath):
        compConfigure.checkFolderPath(folderPath)
        cls.__config['outdir'] = folderPath

    # get overall output path
    @classmethod
    def getOutDir(cls, ):
        return cls.__config['outdir']

    # set genome falg
    @classmethod
    def setGenome(cls, val):
        if compConfigure.getThreads() is None:
            raise commonError("Please set threads before using setGenome.")
        
        cls.__config['genome'] = val

    # get genome falg
    @classmethod
    def getGenome(cls):
        return cls.__config['genome']
            