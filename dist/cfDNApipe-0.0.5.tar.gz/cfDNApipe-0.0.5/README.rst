# cfDNA-Pipeline
Cell Free DNA Sequencing Analysis Pipeline


# News
version 0.0.1, 2019.06.01
The first test version.

version 0.0.4, 2019.11.24
Add functions to check the reference folder when setting configure.
